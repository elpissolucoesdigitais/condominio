<footer class="main-footer main-footer--fixed">
    <div class="container py-5">
        <div class="flex justify-center">
            <p class="text-gray-500 text-center font-medium font-leading px-4">Todos Direitos Reservados a <a
                    href="https://especializati.com.br"
                    class="font-semibold text-white hover:text-green-400">EspecializaTi</a> para o curso <a
                    href="#" class="hover:text-red-400">LaraChat</a></p>
        </div>
    </div>
</footer>
